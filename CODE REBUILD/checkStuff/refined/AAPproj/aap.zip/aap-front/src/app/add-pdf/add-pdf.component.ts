import { Component, OnInit } from '@angular/core';
import { HttpClientModule, HttpClient } from '@angular/common/http';
import { FormGroup, FormControl, ReactiveFormsModule } from '@angular/forms';

@Component({
  selector: 'app-add-pdf',
  templateUrl: './add-pdf.component.html',
  styleUrls: ['./add-pdf.component.css']
})
export class AddPdfComponent implements OnInit {
  columnDefs: any;
  rowData: any;

  profileForm = new FormGroup({
    firstName: new FormControl(''),
    lastName: new FormControl(''),
    image: new FormControl('')
  });
  title = 'helloworld';
  fileData = null;

  startval:number;


  data: any[];
  // settings: any;

  constructor(private http: HttpClient) { }

  ngOnInit() {
    this.startval=0
    console.log('im heheh');
  }

  fileProgress(fileInput: any) {
    this.fileData = <File>fileInput.target.files[0];
  }

  onSubmit() {
    console.log('im her66666e');
    // const formData = new FormData();
    // formData.append('file', this.fileData);
    console.log(this.profileForm.value);


    console.log('im he44444re');
    // this.http.post('http://127.0.0.1:8000/', formData)
    //   .subscribe(res => {
    //     console.log(res);
    //     alert('SUCCESS !!');
    //   })
    let obj = JSON.parse(this.profileForm.value.image);
    console.log(obj);
    this.startval = 1;

    console.log(obj.length);


    this.data = [
      ['first_Name', 'last_Name', 'DOB', 'school_code', 'test_date', 'test_code']
    ];

    let outCheck = []
    for (var key in obj) {
      if (obj.hasOwnProperty(key)) {
        this.data.push([obj[key].first_Name, obj[key].last_Name, obj[key].DOB,
          obj[key].school_code, obj[key].test_date, obj[key].test_code]);
      }



      // this.settings={
      //   data: this.data,
      //   rowHeaders: true,
      //   colHeaders: true,

      //   width=1000,
      //   height=1500,


      //   licenseKey: 'non-commercial-and-evaluation'
      // };

  }





  }

}

