from django.apps import AppConfig


class FilestuffConfig(AppConfig):
    name = 'fileStuff'
